<?php include 'includes/header.php';?>
	<section class="bg-style first-sec" style="background: url('img/bg-iserrve.png');">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-7">
					<div class="hero-section">
						<h1>
							How you can Reduce your Risk in Business?
						</h1>

						<p>
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. At sociis elit ut tristique sed. Hac tincidunt nunc orci habitasse
						</p>
						<div class="hero-cta">
							<a href="#" class="v-theme-btn">TALK TO EXPERT</a>
							<a href="#" class="v-theme-btn2">KNOW MORE <i class="feather icon-feather-chevrons-right"></i></a>
						</div>
					</div>
				</div>
				<div class="col-lg-5">
					<div class="hero-img v-mobo-hide">
						<img src="img/banner_page2.gif" alt="">
					</div>						
				</div>
			</div>
		</div>
	</section>

	<?php include 'includes/footer.php';?>


	


<?php include 'includes/header.php';?>
		
		<section class="first-sec">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-lg-12 margin-20px-bottom">	
							<div class="text-center">
									<h3 class="text-aqua">
										DOWNLOADABLES
									</h3>
									<!-- <a href="#" class="btn-back"><i class="feather icon-feather-chevrons-left"></i> Back</a> -->
								</div>
					</div>
					<div class="col-lg-9">
						<form action="" class="v-form claim">
										<div class="row ">
											<div class="col-lg-9">
												<label class="select" for="slct">
													<span>Select Insurance</span>
													<i class="feather icon-feather-chevron-down"></i>
												<select id="slct" required="required">
									    
									    <option value="#" selectes>HFDC Insurance</option>
									    <option value="#">Tata AIG</option>
									    <option value="#">MAX Life Insurance</option>
									    
									  </select>
									  </label>
									</div>
									<div class="col-lg-3 text-center">	
											<button type="submit" class="v-theme-btn">Search</button>
									</div>	
								</div>
								<hr>
								<div class="row margin-20px-bottom">
									<div class="col-lg-6 margin-20px-bottom">
										<a href="#">
										<div class="download-sec">
											<div class="download-ico">
												<i class="feather icon-feather-file-text"></i>
											</div>
											<div class="download-cont">
												<h6>Lorem ipsum dolor, sit amet, consectetur adipisicing.</h6>
												<span><i>Format: PDF</i></span>
											</div>
											<div class="download-btn">
												<i class="feather icon-feather-download"></i>
											</div>
										</div>
									</a>
									</div>
									<div class="col-lg-6 margin-20px-bottom">
										<a href="#">
										<div class="download-sec">
											<div class="download-ico">
												<i class="feather icon-feather-file-text"></i>
											</div>
											<div class="download-cont">
												<h6>Lorem ipsum dolor, sit amet, consectetur adipisicing.</h6>
												<span><i>Format: PDF</i></span>
											</div>
											<div class="download-btn">
												<i class="feather icon-feather-download"></i>
											</div>
										</div>
									</a>
									</div>
									<div class="col-lg-6 margin-20px-bottom">
										<a href="#">
										<div class="download-sec">
											<div class="download-ico">
												<i class="feather icon-feather-file-text"></i>
											</div>
											<div class="download-cont">
												<h6>Lorem ipsum dolor, sit amet, consectetur adipisicing.</h6>
												<span><i>Format: PDF</i></span>
											</div>
											<div class="download-btn">
												<i class="feather icon-feather-download"></i>
											</div>
										</div>
									</a>
									</div>
									<div class="col-lg-6 margin-20px-bottom">
										<a href="#">
										<div class="download-sec">
											<div class="download-ico">
												<i class="feather icon-feather-file-text"></i>
											</div>
											<div class="download-cont">
												<h6>Lorem ipsum dolor, sit amet, consectetur adipisicing.</h6>
												<span><i>Format: PDF</i></span>
											</div>
											<div class="download-btn">
												<i class="feather icon-feather-download"></i>
											</div>
										</div>
									</a>
									</div>
									<div class="col-lg-6 margin-20px-bottom">
										<a href="#">
										<div class="download-sec">
											<div class="download-ico">
												<i class="feather icon-feather-file-text"></i>
											</div>
											<div class="download-cont">
												<h6>Lorem ipsum dolor, sit amet, consectetur adipisicing.</h6>
												<span><i>Format: PDF</i></span>
											</div>
											<div class="download-btn">
												<i class="feather icon-feather-download"></i>
											</div>
										</div>
									</a>
									</div>
									<div class="col-lg-6 margin-20px-bottom">
										<a href="#">
										<div class="download-sec">
											<div class="download-ico">
												<i class="feather icon-feather-file-text"></i>
											</div>
											<div class="download-cont">
												<h6>Lorem ipsum dolor, sit amet, consectetur adipisicing.</h6>
												<span><i>Format: PDF</i></span>
											</div>
											<div class="download-btn">
												<i class="feather icon-feather-download"></i>
											</div>
										</div>
									</a>
									</div>

								</div>
								</form>
								

						
					</div>
					<div class="col-lg-3">
						<div class="ad-area">
							<img src="img/ad-life.png" alt="">
						</div>
					</div>
				</div>
			</div>
		</section>

<?php include 'includes/footer.php';?>


	


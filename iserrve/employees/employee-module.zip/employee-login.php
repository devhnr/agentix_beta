<?php include 'includes/header.php';?>

	<section class="p-0 first-sec">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="welcome-text text-center">
						<h4>Welcome <span class="text-aqua">Yatrik</span></h4>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="container">
			<div class="row">
				<div class="col-lg-12 margin-20px-bottom">
					<h5 class="v-title-new">
						Your <span class="text-aqua">Policies</span>
					</h5>
				</div>
			</div>
			<div class="row align-items-center justify-content-center" >
				<div class="col-lg-5 col-md-8">
					<a href="#">
					<div class="v-policy-card active-policy">
						<div class="cdp-det-main">
							<div class="cdp-sec-name">
								<div class="cdp-pol-ico">
									<i class="fas fa-building"></i>
								</div>
								<div class="cdp-pol-name">
									<h5>HDFC Health Protection </h5>
								</div>
							</div>
							<div class="cdp-sign">
								<div class="dot-cir">
								</div>
								<span>Activated</span>
							</div>
							<div class="cdp-no">
								<span class="text-para margin-10px-bottom">HDFC Eargo General Insurance</span>
								<h6 class="m-0">Policy No: <span>123456789012345678</span></h6>
							</div>
							<div class="cdp-foot">
								<div class="cdp-dates">
								<div class="cdp-dates-flex">
									<span>Start Date</span>
									<span>01-12-2022</span>
								</div>
								<div class="cdp-dates-flex">
									<span>End Date</span>
									<span>01-12-2022</span>
								</div>

									
							</div>


							
								
						</div>	

						<div class="cdp-tpa-flex">
									<span>TPA</span>
									<span>Health India Private Limited</span>
								</div>
							</div>
					</div>
					</a>
				</div>
				<div class="col-lg-5  col-md-8">
					<a href="#">
					<div class="v-policy-card ">
						<div class="cdp-det-main">
							<div class="cdp-sec-name">
								<div class="cdp-pol-ico">
									<i class="fas fa-building"></i>
								</div>
								<div class="cdp-pol-name">
									<h5>HDFC Health Protection </h5>
								</div>
							</div>
							<div class="cdp-sign">
								<div class="dot-cir">
								</div>
								<span>Paused</span>
							</div>
							<div class="cdp-no">
								<span class="text-para margin-10px-bottom">HDFC Eargo General Insurance</span>
								<h6 class="m-0">Policy No: <span>123456789012345678</span></h6>
							</div>
							<div class="cdp-foot">
								<div class="cdp-dates">
								<div class="cdp-dates-flex">
									<span>Start Date</span>
									<span>01-12-2022</span>
								</div>
								<div class="cdp-dates-flex">
									<span>End Date</span>
									<span>01-12-2022</span>
								</div>

								
							</div>
							
								
						</div>	

						<div class="cdp-tpa-flex">
									<span>TPA</span>
									<span>Health India Private Limited</span>
								</div>
							</div>
					</div>
					</a>
				</div>
				<div class="col-lg-2">
					<div class="pol-btn">
						<a href="#"><span>VIEW MORE</span><i class="feather icon-feather-arrow-right"></i> </a>
					</div>
				</div>	
			</div>
		</div>
	</section>

	<section class="bg-light">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 margin-20px-bottom">
					<h5 class="v-title-new">
						Iserrve <span class="text-aqua">Assessment</span>
					</h5>
				</div>
			</div>
			<div class="row">
				<div class="col">
                        <div class="swiper-container black-move swiper-pagination-bottom" data-slider-options='{ "loop": true, "slidesPerView": 1, "spaceBetween": 30, "observer": true, "observeParents": true, "autoplay": { "delay": 2500, "disableOnInteraction": false }, "pagination": { "el": ".swiper-pagination", "clickable": true, "dynamicBullets": true }, "keyboard": { "enabled": true, "onlyInViewport": true }, "breakpoints": { "1200": { "slidesPerView": 4 }, "992": { "slidesPerView": 3 }, "768": { "slidesPerView": 2 }, "400": { "slidesPerView": 2 } } }'>
                            <div class="swiper-wrapper">
                                <!-- start team member slider item -->
	                               <div class="swiper-slide">
							        	<a href="#" class="assess-banner"><img src="img/assess1.jpg" alt=""></a>
							        </div>
							        <div class="swiper-slide">
							        	<a href="#" class="assess-banner"><img src="img/assess2.jpg" alt=""></a>
							        </div>
							        <div class="swiper-slide">
							        	<a href="#" class="assess-banner"><img src="img/assess3.jpg" alt=""></a>
							        </div>
							        <div class="swiper-slide">
							        	<a href="#" class="assess-banner"><img src="img/assess2.jpg" alt=""></a>
							        </div>
							        <div class="swiper-slide">
							        	<a href="#" class="assess-banner"><img src="img/assess3.jpg" alt=""></a>
							        </div>
                                <!-- end team member slider item -->
                            </div>
                            <!-- start slider pagination -->
                            <div class="swiper-pagination"></div>
                            <!-- end slider pagination -->
                        </div>
                    </div>
			</div>
		</div>
	</section>

	<section>
		<div class="container">
			<div class="row">
				<div class="col-lg-12 margin-20px-bottom">
					<h5 class="v-title-new">
						Iserrve <span class="text-aqua">Protection</span>
					</h5>
				</div>
			</div>
		</div>
		<div class="container-fluid">
			<div class="empprod-scroll">
				<div  class="scroll-link">
					<div class="empprod-dec prodgrad-blue">
                                			<div class="emp-prod">
                                		
                                		<div class="ep-name">
                                			<h6>HDFC Health Insurance</h6>
                                		</div>

                                		<div class="emp-link">
                                			<a href="#"><i class="feather icon-feather-arrow-right"></i></a>
                                		</div>

                                	</div>
                                	     <div class="ep-img">
                                			<img src="img/empprod1.png" alt="" data-no-retina="">
                                		</div>
                                	</div>
				</div>

				<div  class="scroll-link">
					<div class="empprod-dec prodgrad-pink">
                                			<div class="emp-prod">
                                		
                                		<div class="ep-name">
                                			<h6>Tata Cyber Insurance</h6>
                                		</div>

                                		<div class="emp-link">
                                			<a href="#"><i class="feather icon-feather-arrow-right"></i></a>
                                		</div>

                                	</div>
                                	     <div class="ep-img">
                                			<img src="img/emprod2.png" alt="" data-no-retina="">
                                		</div>
                                	</div>
				</div>

				<div class="scroll-link">
					<div class="empprod-dec prodgrad-yellow">
                                			<div class="emp-prod">
                                		
                                		<div class="ep-name">
                                			<h6>Lorem ipsum dolor sit, amet.</h6>
                                		</div>

                                		<div class="emp-link">
                                			<a href="#"><i class="feather icon-feather-arrow-right"></i></a>
                                		</div>

                                	</div>
                                	     <div class="ep-img">
                                			<img src="img/empprod3.png" alt="" data-no-retina="">
                                		</div>
                                	</div>
				</div>

				<div  class="scroll-link">
					<div class="empprod-dec prodgrad-green">
                                			<div class="emp-prod">
                                		
                                		<div class="ep-name">
                                			<h6>Lorem ipsum dolor sit, amet.</h6>
                                		</div>

                                		<div class="emp-link">
                                			<a href="#"><i class="feather icon-feather-arrow-right"></i></a>
                                		</div>

                                	</div>
                                	     <div class="ep-img">
                                			<img src="img/emprod2.png" alt="" data-no-retina="">
                                		</div>
                                	</div>
				</div>

				<div  class="scroll-link">
					<div class="empprod-dec prodgrad-pink">
                                			<div class="emp-prod">
                                		
                                		<div class="ep-name">
                                			<h6>Lorem ipsum dolor sit, amet.</h6>
                                		</div>

                                		<div class="emp-link">
                                			<a href="#"><i class="feather icon-feather-arrow-right"></i></a>
                                		</div>

                                	</div>
                                	     <div class="ep-img">
                                			<img src="img/empprod3.png" alt="" data-no-retina="">
                                		</div>
                                	</div>
				</div>

				<div class="scroll-link">
					<div class="empprod-dec prodgrad-blue">
                                			<div class="emp-prod">
                                		
                                		<div class="ep-name">
                                			<h6>Lorem ipsum dolor sit, amet.</h6>
                                		</div>

                                		<div class="emp-link">
                                			<a href="#"><i class="feather icon-feather-arrow-right"></i></a>
                                		</div>

                                	</div>
                                	     <div class="ep-img">
                                			<img src="img/empprod1.png" alt="" data-no-retina="">
                                		</div>
                                	</div>
				</div>
			</div>
		
		</div>
		
	</section>

	<section class="bg-light">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 margin-20px-bottom">
					<h5 class="v-title-new">
						Iserrve <span class="text-aqua">Prevention</span>
					</h5>
				</div>
			</div>
			<div class="row">
				<div class="col">
                        <div class="swiper-container black-move swiper-pagination-bottom" data-slider-options='{ "loop": true, "slidesPerView": 1, "spaceBetween": 30, "observer": true, "observeParents": true, "autoplay": { "delay": 2500, "disableOnInteraction": false }, "pagination": { "el": ".swiper-pagination", "clickable": true, "dynamicBullets": true }, "keyboard": { "enabled": true, "onlyInViewport": true }, "breakpoints": { "1200": { "slidesPerView": 4 }, "992": { "slidesPerView": 3 }, "768": { "slidesPerView": 2 } } }'>
                            <div class="swiper-wrapper">
                                <!-- start team member slider item -->
                               <div class="swiper-slide">
        	<a href="#" class="assess-banner"><img src="img/assess1.jpg" alt=""></a>
        </div>
        <div class="swiper-slide">
        	<a href="#" class="assess-banner"><img src="img/assess2.jpg" alt=""></a>
        </div>
        <div class="swiper-slide">
        	<a href="#" class="assess-banner"><img src="img/assess3.jpg" alt=""></a>
        </div>
        <div class="swiper-slide">
        	<a href="#" class="assess-banner"><img src="img/assess2.jpg" alt=""></a>
        </div>
        <div class="swiper-slide">
        	<a href="#" class="assess-banner"><img src="img/assess3.jpg" alt=""></a>
        </div>
                                <!-- end team member slider item -->
                            </div>
                            <!-- start slider pagination -->
                            <div class="swiper-pagination"></div>
                            <!-- end slider pagination -->
                        </div>
                    </div>
			</div>
		</div>
	</section>

	
					
	








	
<?php include 'includes/footer.php';?>




	